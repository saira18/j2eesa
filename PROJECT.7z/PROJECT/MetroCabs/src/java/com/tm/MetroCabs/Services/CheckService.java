
package java.com.tm.MetroCabs.Services;

import java.com.tm.MetroCabs.DaoImplementations.CheckDaoImplementation;
import java.com.tm.MetroCabs.DaoInterfaces.CheckDao;
import java.com.tm.MetroCabs.beans.Cab;
import java.sql.SQLException;

public class CheckService {
   public int checkAvailability(Cab cab)throws ClassNotFoundException,SQLException{
      CheckDao checkDao=new CheckDaoImplementation();
      return checkDao.checkAvailability(cab);
   }

   
}
