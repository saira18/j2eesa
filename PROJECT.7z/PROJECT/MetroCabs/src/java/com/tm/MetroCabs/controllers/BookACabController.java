
package java.com.tm.MetroCabs.controllers;

import java.com.tm.MetroCabs.Services.UserService;
import java.com.tm.MetroCabs.beans.CabBooking;
import java.com.tm.MetroCabs.beans.Customer;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BookACabController extends HttpServlet {
 
 @Override
 public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
   CabBooking cb=new CabBooking();
   Customer cus=new Customer();
   
   cb.setCity(request.getParameter("city"));
   cb.setDate(request.getParameter("Date"));
   cb.setPickUpTime(request.getParameter("time"));
   cb.setPickUpPlace(request.getParameter("place"));
   cb.setTypeOfService(request.getParameter("service"));
   cb.setNo_of_Persons(Integer.parseInt(request.getParameter("persons")));
   cb.setDestination(request.getParameter("dest"));
   cb.setCabType(request.getParameter("type"));
   cus.setName(request.getParameter("Cname"));
   cus.setMobileNo(request.getParameter("mobileNo"));
   cus.setEmailId(request.getParameter("emailId"));
   UserService us=new UserService();
   try{
       int j=us.addUser(cus);
       if(j>0){
           RequestDispatcher rd1=request.getRequestDispatcher("/BookId.html");
           rd1.include(request,response);
       }
       else{
           RequestDispatcher rd2=request.getRequestDispatcher("/checkfail.html");
           rd2.include(request, response);
       }
   } catch (ClassNotFoundException ex) {
         ex.printStackTrace();
     } catch (SQLException ed) {
        ed.printStackTrace();
     }
   
 }
   
}
