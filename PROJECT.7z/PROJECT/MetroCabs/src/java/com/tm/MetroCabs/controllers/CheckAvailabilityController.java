
package java.com.tm.MetroCabs.controllers;

import java.com.tm.MetroCabs.Services.CheckService;
import java.com.tm.MetroCabs.beans.Cab;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CheckAvailabilityController extends HttpServlet {
 public CheckAvailabilityController() {
        super();
    }
    @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
   String city=request.getParameter("city");
   String type=request.getParameter("type");
   Cab cab=new Cab();
   cab.setCity(city);
   cab.setCabType(type); 
   CheckService service=new CheckService();
    try{
        int j=service.checkAvailability(cab);
        if(j>0){
            RequestDispatcher rd=request.getRequestDispatcher("/checksuc.html");
            rd.include(request,response);
        }
        else{
            RequestDispatcher rd2=request.getRequestDispatcher("/checkfail.html");
            rd2.include(request,response);
        }  
    }catch(ClassNotFoundException ce){
       ce.printStackTrace();
    }catch(SQLException se){
        se.printStackTrace();
    }
    }
    
}
