
package java.com.tm.MetroCabs.beans;

public class CabBooking {
    private String city;
    private String date;
    private String pickUpTime;
    private String pickUpPlace;
    private String typeOfService;
    private int no_of_Persons;
    private String cabType;
    private String destination;
    
     public CabBooking(){
        super();
    }
    CabBooking(String city,String date,String pickUpTime,String pickUpPlace,String typeOfService,int no_of_Persons,String cabType,String destination){
        this.cabType=cabType;
        this.city=city;
        this.date=date;
        this.destination=destination;
        this.pickUpPlace=pickUpPlace;
        this.no_of_Persons=no_of_Persons;
        this.typeOfService=typeOfService;
        this.pickUpTime=pickUpTime;
    }
    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the pickUpTime
     */
    public String getPickUpTime() {
        return pickUpTime;
    }

    /**
     * @param pickUpTime the pickUpTime to set
     */
    public void setPickUpTime(String pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    /**
     * @return the pickUpPlace
     */
    public String getPickUpPlace() {
        return pickUpPlace;
    }

    /**
     * @param pickUpPlace the pickUpPlace to set
     */
    public void setPickUpPlace(String pickUpPlace) {
        this.pickUpPlace = pickUpPlace;
    }

    /**
     * @return the typeOfService
     */
    public String getTypeOfService() {
        return typeOfService;
    }

    /**
     * @param typeOfService the typeOfService to set
     */
    public void setTypeOfService(String typeOfService) {
        this.typeOfService = typeOfService;
    }

    /**
     * @return the no_of_Persons
     */
    public int getNo_of_Persons() {
        return no_of_Persons;
    }

    /**
     * @param no_of_Persons the no_of_Persons to set
     */
    public void setNo_of_Persons(int no_of_Persons) {
        this.no_of_Persons = no_of_Persons;
    }

    /**
     * @return the cabType
     */
    public String getCabType() {
        return cabType;
    }

    /**
     * @param cabType the cabType to set
     */
    public void setCabType(String cabType) {
        this.cabType = cabType;
    }

    /**
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * @param destination the destination to set
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }
    @Override
    public String toString(){
        return this.cabType+this.city+this.date+this.destination+this.pickUpPlace+this.pickUpTime+this.typeOfService;
    }
}
