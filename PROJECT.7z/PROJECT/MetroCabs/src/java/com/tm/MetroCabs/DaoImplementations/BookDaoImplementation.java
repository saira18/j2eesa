
package java.com.tm.MetroCabs.DaoImplementations;

import java.com.tm.MetroCabs.JDBCUtils.JDBCUtil;
import java.com.tm.MetroCabs.beans.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BookDaoImplementation {
    public int addUserDetails(Customer cus)throws ClassNotFoundException,SQLException{
      Connection con=JDBCUtil.getConnection();
//      Customer cust=new Customer();
      PreparedStatement pm=con.prepareStatement("INSERT INTO METRO_USER VALUES('?','?','?')");
      pm.setString(1,cus.getName());
      pm.setString(2,cus.getMobileNo());
      pm.setString(3,cus.getEmailId());
      int res=pm.executeUpdate();
      return res;
    }
//    public int generateBookId(Customer cus)throws ClassNotFoundException,SQLException{
//        Connection con=JDBCUtil.getConnection();
//        Customer custo=new Customer();
//        
//    }
}
