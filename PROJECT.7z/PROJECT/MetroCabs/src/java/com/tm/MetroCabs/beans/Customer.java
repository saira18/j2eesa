
package java.com.tm.MetroCabs.beans;

public class Customer {
    private String name;
    private String mobileNo;
    private String emailId;
    private String city;
    public Customer(){
        super();
    }
    Customer(String name,String mobileNo,String emailId,String city){
        this.city=city;
        this.emailId=emailId;
        this.mobileNo=mobileNo;
        this.name=name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the mobileNo
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * @param mobileNo the mobileNo to set
     */
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }
    @Override
    public String toString(){
        return this.city+this.emailId+this.name+this.mobileNo;
    }
}
