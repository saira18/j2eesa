
package java.com.tm.MetroCabs.Services;

import java.com.tm.MetroCabs.DaoImplementations.BookDaoImplementation;
import java.com.tm.MetroCabs.DaoInterfaces.BookDao;
import java.com.tm.MetroCabs.beans.Customer;
import java.sql.SQLException;

public class UserService {
    public int addUser(Customer cus)throws ClassNotFoundException,SQLException{
      BookDaoImplementation userDao=new BookDaoImplementation();
      return userDao.addUserDetails(cus);
    }
}
