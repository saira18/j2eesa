
package java.com.tm.MetroCabs.DaoInterfaces;

import java.com.tm.MetroCabs.beans.Cab;
import java.sql.SQLException;

public interface CheckDao {
    public abstract int checkAvailability(Cab cab)throws ClassNotFoundException,SQLException;
}
