
package java.com.tm.MetroCabs.beans;

public class Cab {
    private int cabNo;
    private String cabType;
    private String driverName;
    private String cabService;
    private long driverMobileNo;
    private String city;
    private String status;
   
    public Cab(){
        super();
    }
    Cab(int cabNo,String cabType,String driverName,String cabService,long driverMobileNo,String city,String status){
        this.cabNo=cabNo;
        this.cabService=cabService;
        this.cabType=cabType;
        this.city=city;
        this.driverName=driverName;
        this.driverMobileNo=driverMobileNo; 
        this.status=status;
    }

//    public Cab() {
//        throw new UnsupportedOperationException("Not yet implemented");
//    }

    /**
     * @return the cabNo
     */
    public int getCabNo() {
        return cabNo;
    }

    /**
     * @param cabNo the cabNo to set
     */
    public void setCabNo(int cabNo) {
        this.cabNo = cabNo;
    }

    /**
     * @return the cabType
     */
    public String getCabType() {
        return cabType;
    }

    /**
     * @param cabType the cabType to set
     */
    public void setCabType(String cabType) {
        this.cabType = cabType;
    }

    /**
     * @return the driverName
     */
    public String getDriverName() {
        return driverName;
    }

    /**
     * @param driverName the driverName to set
     */
    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    /**
     * @return the cabService
     */
    public String getCabService() {
        return cabService;
    }

    /**
     * @param cabService the cabService to set
     */
    public void setCabService(String cabService) {
        this.cabService = cabService;
    }

    /**
     * @return the driverMobileNo
     */
    public long getDriverMobileNo() {
        return driverMobileNo;
    }

    /**
     * @param driverMobileNo the driverMobileNo to set
     */
    public void setDriverMobileNo(long driverMobileNo) {
        this.driverMobileNo = driverMobileNo;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }
    public void setStatus(String status){
        this.status=status;
    }
    public String getStatus(){
        return status;
    }
    @Override
public String toString(){
    return this.cabNo+this.cabService+this.cabType+this.driverName+this.city+this.driverMobileNo+this.status;
}
}
