
package com.tm.MetroCabs.Services;

import com.tm.MetroCabs.DaoImplementations.CheckDaoImplementation;
import com.tm.MetroCabs.DaoInterfaces.CheckDao;
import com.tm.MetroCabs.beans.Cab;
import java.sql.SQLException;

public class CheckService {
   public int checkAvailability(Cab cab)throws ClassNotFoundException,SQLException{
      CheckDao checkDao=new CheckDaoImplementation();
      return checkDao.checkAvailability(cab);
   }

   
}
