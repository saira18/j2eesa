
package com.tm.MetroCabs.DaoImplementations;

import com.tm.MetroCabs.DaoInterfaces.CheckDao;
import com.tm.MetroCabs.JDBCUtils.JDBCUtil;
import com.tm.MetroCabs.beans.Cab;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CheckDaoImplementation implements CheckDao{

    
    public int checkAvailability(Cab cab)throws ClassNotFoundException,SQLException
    {
        
        Connection con=JDBCUtil.getConnection();
        PreparedStatement ps=con.prepareStatement("SELECT CAB_COLOR FROM METRO_CAB WHERE LOCATION=? AND TYPE_OF_VEHICLE=? AND CAB_COLOR='INDIGO'");
        ps.setString(1,cab.getCity());
        ps.setString(2,cab.getCabType());
        System.out.println(cab.getCity());
        System.out.println(cab.getCabType());
        int result=ps.executeUpdate();
        return result;
    }

   
}
