
package com.tm.MetroCabs.DaoInterfaces;

import com.tm.MetroCabs.beans.Customer;
import java.sql.SQLException;

public interface BookDao {
    public abstract int addUserDetails(Customer cus)throws ClassNotFoundException,SQLException;
    public abstract int generateBookId(Customer cus)throws ClassNotFoundException,SQLException;
}
