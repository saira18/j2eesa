
package com.tm.MetroCabs.Services;

import com.tm.MetroCabs.DaoImplementations.BookDaoImplementation;
import com.tm.MetroCabs.DaoInterfaces.BookDao;
import com.tm.MetroCabs.beans.Customer;
import java.sql.SQLException;

public class UserService {
    public int addUser(Customer cus)throws ClassNotFoundException,SQLException{
      BookDaoImplementation userDao=new BookDaoImplementation();
      return userDao.addUserDetails(cus);
    }
}
