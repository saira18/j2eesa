
package com.tm.MetroCabs.beans;

public class FeedBack {
    private int bookingId;
    private String feedBack;
    FeedBack(){
        super();
    }
    FeedBack(int bookingId,String feedBack){
        this.bookingId=bookingId;
        this.feedBack=feedBack;
    }

    /**
     * @return the bookingId
     */
    public int getBookingId() {
        return bookingId;
    }

    /**
     * @param bookingId the bookingId to set
     */
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    /**
     * @return the feedBack
     */
    public String getFeedBack() {
        return feedBack;
    }

    /**
     * @param feedBack the feedBack to set
     */
    public void setFeedBack(String feedBack) {
        this.feedBack = feedBack;
    }
    @Override
    public String toString(){
     return this.feedBack+this.bookingId;   
    }
            
}
