
package com.tm.MetroCabs.Exceptions;

import com.tm.MetroCabs.beans.Cab;

public class CheckException {
    public int checkDao(Cab cab){
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
